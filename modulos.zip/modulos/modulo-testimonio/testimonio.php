<div class="pt-3 pb-5 pl-5 pr-5">
    <div class="row d-flex justify-content-center">

<?php

$paged = (get_query_var('page')) ? get_query_var('page') : 1;
/*Query para pedir las publicaciones del tipo "pokemon", se debe ajustar el "posts_per_page" para cambiar el número de publicaciones por página*/
$args = array(
    'post_type'=>'pokemon',
    'posts_per_page' => 20,
    'paged' => $paged,
	/*Orden por custom field "numero"*/
	'orderby'			=> 'numero',
	'order'				=> 'ASC'
);
/*Bucle para traer publicaciones*/
$loop = new WP_Query( $args );
if ( $loop->have_posts() ) {
    while ( $loop->have_posts() ) : $loop->the_post();?>

              <!-- Cada Pokémon se muestra como tarjeta de Bootstrap -->
                <div class="card text-center p-2 m-2 col-12 col-md-3 col-lg-2 text-white bloque-texto" >
                    <!-- Imagen del Pokémon -->
                    <img class="card-img-top bg-img" src="<?php echo wp_get_attachment_url(get_post_thumbnail_id($post->ID)); ?>" alt="<?php echo get_the_title(); ?>">
                <!-- Cuerpo de la tarjeta -->
                    <div class="card-body px-0">
						<!-- Número y nombre del Pokémon -->
						<h6>N° <?php echo the_field('numero')?></h6>
                        <h5 class="card-title font-weight-bold"> <?php echo get_the_title(); ?></h5>
						<!-- Tipos del Pokémon, el segundo solo se muestra si aplica -->
						<p>
							<span><?php echo the_field('tipo-1')?></span> <span class="t-2"> <?php echo the_field('tipo-2')?></span>
						</p>

						<!-- Y el enlace para ver el Pokémon -->
                        <a href="<?php the_permalink(); ?>" class="btn btn-warning">Ver más</a>
                    </div>
                </div>

    <?php endwhile;

    $total_pages = $loop->max_num_pages;

    if ($total_pages > 1){

        $current_page = max(1, get_query_var('page'));?>
		
		<!-- Paginación -->
		<div id="pagination" class="col-12">
			
   
         <?php echo paginate_links(array(
            'base' => get_pagenum_link(1) . '%_%',
            'format' => 'page/%#%',
            'current' => $current_page,
            'total' => $total_pages,
            'prev_text'    => __('<i class="fas fa-caret-left"></i>'),
            'next_text'    => __('<i class="fas fa-caret-right"></i>'),
			'type' => 'list',
        ));
    }    
}
wp_reset_postdata();
?>
		</div>

     
</div>
</div>